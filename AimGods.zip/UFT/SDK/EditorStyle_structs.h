#pragma once

// Name: AimGods, Version: 1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Enums
//---------------------------------------------------------------------------

// Enum EditorStyle.EAssetEditorOpenLocation
enum class EAssetEditorOpenLocation : uint8_t
{
	Default                        = 0,
	NewWindow                      = 1,
	MainWindow                     = 2,
	ContentBrowser                 = 3,
	LastDockedWindowOrNewWindow    = 4,
	LastDockedWindowOrMainWindow   = 5,
	LastDockedWindowOrContentBrowser = 6,
	MAX                            = 7,

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
