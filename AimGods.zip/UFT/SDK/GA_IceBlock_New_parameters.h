#pragma once

// Name: AimGods, Version: 1

#include "../SDK.h"

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function GA_IceBlock_New.GA_IceBlock_New_C.K2_ActivateAbility
struct UGA_IceBlock_New_C_K2_ActivateAbility_Params
{
};

// Function GA_IceBlock_New.GA_IceBlock_New_C.ExecuteUbergraph_GA_IceBlock_New
struct UGA_IceBlock_New_C_ExecuteUbergraph_GA_IceBlock_New_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
