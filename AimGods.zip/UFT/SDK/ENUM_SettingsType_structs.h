#pragma once

// Name: AimGods, Version: 1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Enums
//---------------------------------------------------------------------------

// UserDefinedEnum ENUM_SettingsType.ENUM_SettingsType
enum class ENUM_SettingsType : uint8_t
{
	NewEnumerator0                 = 0,
	NewEnumerator1                 = 1,
	NewEnumerator3                 = 2,
	NewEnumerator2                 = 3,
	ENUM_MAX                       = 4,

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
