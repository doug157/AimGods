#pragma once

// Name: AimGods, Version: 1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Enums
//---------------------------------------------------------------------------

// UserDefinedEnum ENiagaraBooleanLogicOps.ENiagaraBooleanLogicOps
enum class ENiagaraBooleanLogicOps : uint8_t
{
	NewEnumerator0                 = 0,
	NewEnumerator2                 = 1,
	NewEnumerator4                 = 2,
	NewEnumerator5                 = 3,
	MAX                            = 4,

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
