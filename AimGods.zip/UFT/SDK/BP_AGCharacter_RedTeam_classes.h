#pragma once

// Name: AimGods, Version: 1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BP_AGCharacter_RedTeam.BP_AGCharacter_RedTeam_C
// 0x0000 (FullSize[0x09B4] - InheritedSize[0x09B4])
class ABP_AGCharacter_RedTeam_C : public ABP_AGCharacter_C
{
public:


	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass BP_AGCharacter_RedTeam.BP_AGCharacter_RedTeam_C");
		return ptr;
	}


};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
