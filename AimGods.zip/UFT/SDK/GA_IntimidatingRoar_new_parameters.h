#pragma once

// Name: AimGods, Version: 1

#include "../SDK.h"

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function GA_IntimidatingRoar_new.GA_IntimidatingRoar_new_C.CheckAndSetupCachables
struct UGA_IntimidatingRoar_new_C_CheckAndSetupCachables_Params
{
};

// Function GA_IntimidatingRoar_new.GA_IntimidatingRoar_new_C.K2_ActivateAbility
struct UGA_IntimidatingRoar_new_C_K2_ActivateAbility_Params
{
};

// Function GA_IntimidatingRoar_new.GA_IntimidatingRoar_new_C.ExecuteUbergraph_GA_IntimidatingRoar_new
struct UGA_IntimidatingRoar_new_C_ExecuteUbergraph_GA_IntimidatingRoar_new_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
