#pragma once

// Name: AimGods, Version: 1

#include "../SDK.h"

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function GA_Armor_New.GA_Armor_New_C.K2_ActivateAbility
struct UGA_Armor_New_C_K2_ActivateAbility_Params
{
};

// Function GA_Armor_New.GA_Armor_New_C.ExecuteUbergraph_GA_Armor_New
struct UGA_Armor_New_C_ExecuteUbergraph_GA_Armor_New_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
