#pragma once

// Name: AimGods, Version: 1

#include "../SDK.h"

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function GA_Cleanse.GA_Cleanse_C.K2_ActivateAbility
struct UGA_Cleanse_C_K2_ActivateAbility_Params
{
};

// Function GA_Cleanse.GA_Cleanse_C.ExecuteUbergraph_GA_Cleanse
struct UGA_Cleanse_C_ExecuteUbergraph_GA_Cleanse_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
