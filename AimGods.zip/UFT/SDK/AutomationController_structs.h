#pragma once

// Name: AimGods, Version: 1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Enums
//---------------------------------------------------------------------------

// Enum AutomationController.EAutomationArtifactType
enum class EAutomationArtifactType : uint8_t
{
	None                           = 0,
	Image                          = 1,
	Comparison                     = 2,
	MAX                            = 3,

};

// Enum AutomationController.EAutomationState
enum class EAutomationState : uint8_t
{
	NotRun                         = 0,
	InProcess                      = 1,
	Fail                           = 2,
	Success                        = 3,
	NotEnoughParticipants          = 4,
	MAX                            = 5,

};

//---------------------------------------------------------------------------
// Script Structs
//---------------------------------------------------------------------------

// ScriptStruct AutomationController.AutomatedTestResult
// 0x0060
struct FAutomatedTestResult
{
	unsigned char                                      UnknownData_R73U[0x10];                                    // 0x0000(0x0010) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
	struct FString                                     TestDisplayName;                                           // 0x0010(0x0010) (ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     FullTestPath;                                              // 0x0020(0x0010) (ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	EAutomationState                                   State;                                                     // 0x0030(0x0001) (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	unsigned char                                      UnknownData_H8JQ[0x7];                                     // 0x0031(0x0007) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
	TArray<struct FAutomationExecutionEntry>           Entries;                                                   // 0x0038(0x0010) (ZeroConstructor, NativeAccessSpecifierPrivate)
	int                                                Warnings;                                                  // 0x0048(0x0004) (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPrivate)
	int                                                Errors;                                                    // 0x004C(0x0004) (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPrivate)
	TArray<struct FAutomationArtifact>                 Artifacts;                                                 // 0x0050(0x0010) (ZeroConstructor, NativeAccessSpecifierPrivate)

};
// ScriptStruct AutomationController.AutomationArtifact
// 0x00C8
struct FAutomationArtifact
{
	struct FGuid                                       ID;                                                        // 0x0000(0x0010) (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FString                                     Name;                                                      // 0x0010(0x0010) (ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	EAutomationArtifactType                            Type;                                                      // 0x0020(0x0001) (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	unsigned char                                      UnknownData_JO30[0x7];                                     // 0x0021(0x0007) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
	TMap<struct FString, struct FString>               Files;                                                     // 0x0028(0x0050) (ZeroConstructor, NativeAccessSpecifierPublic)
	unsigned char                                      UnknownData_D4PS[0x50];                                    // 0x0078(0x0050) MISSED OFFSET (PADDING)

};
// ScriptStruct AutomationController.AutomatedTestPassResults
// 0x0050
struct FAutomatedTestPassResults
{
	struct FString                                     ClientDescriptor;                                          // 0x0000(0x0010) (ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FDateTime                                   ReportCreatedOn;                                           // 0x0010(0x0008) (ZeroConstructor, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	int                                                Succeeded;                                                 // 0x0018(0x0004) (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	int                                                SucceededWithWarnings;                                     // 0x001C(0x0004) (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	int                                                Failed;                                                    // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	int                                                NotRun;                                                    // 0x0024(0x0004) (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	float                                              TotalDuration;                                             // 0x0028(0x0004) (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               ComparisonExported;                                        // 0x002C(0x0001) (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	unsigned char                                      UnknownData_MTUG[0x3];                                     // 0x002D(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
	struct FString                                     ComparisonExportDirectory;                                 // 0x0030(0x0010) (ZeroConstructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TArray<struct FAutomatedTestResult>                Tests;                                                     // 0x0040(0x0010) (ZeroConstructor, NativeAccessSpecifierPublic)

};
// ScriptStruct AutomationController.AutomatedTestFilter
// 0x0018
struct FAutomatedTestFilter
{
	struct FString                                     Contains;                                                  // 0x0000(0x0010) (ZeroConstructor, Config, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               MatchFromStart;                                            // 0x0010(0x0001) (ZeroConstructor, Config, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	unsigned char                                      UnknownData_LNVS[0x7];                                     // 0x0011(0x0007) MISSED OFFSET (PADDING)

};
// ScriptStruct AutomationController.AutomatedTestGroup
// 0x0020
struct FAutomatedTestGroup
{
	struct FString                                     Name;                                                      // 0x0000(0x0010) (ZeroConstructor, Config, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	TArray<struct FAutomatedTestFilter>                Filters;                                                   // 0x0010(0x0010) (ZeroConstructor, Config, NativeAccessSpecifierPublic)

};
}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
