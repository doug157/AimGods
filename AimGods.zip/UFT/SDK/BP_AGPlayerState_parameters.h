#pragma once

// Name: AimGods, Version: 1

#include "../SDK.h"

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function BP_AGPlayerState.BP_AGPlayerState_C.ReceiveBeginPlay
struct ABP_AGPlayerState_C_ReceiveBeginPlay_Params
{
};

// Function BP_AGPlayerState.BP_AGPlayerState_C.ExecuteUbergraph_BP_AGPlayerState
struct ABP_AGPlayerState_C_ExecuteUbergraph_BP_AGPlayerState_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
