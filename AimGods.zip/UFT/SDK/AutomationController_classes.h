#pragma once

// Name: AimGods, Version: 1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// Class AutomationController.AutomationControllerSettings
// 0x0018 (FullSize[0x0048] - InheritedSize[0x0030])
class UAutomationControllerSettings : public UObject
{
public:
	TArray<struct FAutomatedTestGroup>                 Groups;                                                    // 0x0030(0x0010) (ZeroConstructor, Config, NativeAccessSpecifierPublic)
	bool                                               bTreatLogErrorsAsTestErrors;                               // 0x0040(0x0001) (ZeroConstructor, Config, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	bool                                               bTreatLogWarningsAsTestErrors;                             // 0x0041(0x0001) (ZeroConstructor, Config, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	unsigned char                                      UnknownData_XZTI[0x6];                                     // 0x0042(0x0006) MISSED OFFSET (PADDING)


	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("Class AutomationController.AutomationControllerSettings");
		return ptr;
	}


};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
