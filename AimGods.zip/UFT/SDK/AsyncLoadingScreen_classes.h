#pragma once

// Name: AimGods, Version: 1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// Class AsyncLoadingScreen.LoadingScreenSettings
// 0x0AC8 (FullSize[0x0B08] - InheritedSize[0x0040])
class ULoadingScreenSettings : public UDeveloperSettings
{
public:
	struct FALoadingScreenSettings                     StartupLoadingScreen;                                      // 0x0040(0x0330) (Edit, Config, NativeAccessSpecifierPublic)
	struct FALoadingScreenSettings                     DefaultLoadingScreen;                                      // 0x0370(0x0330) (Edit, Config, NativeAccessSpecifierPublic)
	struct FClassicLayoutSettings                      Classic;                                                   // 0x06A0(0x00A8) (Edit, Config, NativeAccessSpecifierPublic)
	struct FCenterLayoutSettings                       Center;                                                    // 0x0748(0x00A0) (Edit, Config, NativeAccessSpecifierPublic)
	struct FLetterboxLayoutSettings                    Letterbox;                                                 // 0x07E8(0x0138) (Edit, Config, NativeAccessSpecifierPublic)
	struct FSidebarLayoutSettings                      Sidebar;                                                   // 0x0920(0x00B0) (Edit, Config, NativeAccessSpecifierPublic)
	struct FDualSidebarLayoutSettings                  DualSidebar;                                               // 0x09D0(0x0138) (Edit, Config, NativeAccessSpecifierPublic)


	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("Class AsyncLoadingScreen.LoadingScreenSettings");
		return ptr;
	}


};

// Class AsyncLoadingScreen.AsyncLoadingScreenLibrary
// 0x0000 (FullSize[0x0030] - InheritedSize[0x0030])
class UAsyncLoadingScreenLibrary : public UBlueprintFunctionLibrary
{
public:


	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("Class AsyncLoadingScreen.AsyncLoadingScreenLibrary");
		return ptr;
	}


	void STATIC_SetDisplayTipTextIndex(int TipTextIndex);
	void STATIC_SetDisplayMovieIndex(int MovieIndex);
	void STATIC_SetDisplayBackgroundIndex(int BackgroundIndex);
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
